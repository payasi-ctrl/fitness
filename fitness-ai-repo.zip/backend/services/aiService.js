import OpenAI from 'openai';
import dotenv from 'dotenv';
dotenv.config();
const client = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

export async function generateMealPlan(profile, targets){
  const prompt = `Create a 7-day vegetarian high-calorie meal plan for weight gain.
Daily calories: ${targets.calories} kcal
Protein target: ${targets.protein} g
Profile: Age ${profile.age}, Height ${profile.height_cm}, Weight ${profile.weight_kg}, Target ${profile.target_kg}.
Return JSON with keys: summary, days (array of {day, meals:[{name,calories,protein}]})` ;
  const res = await client.chat.completions.create({
    model: "gpt-4o-mini",
    messages: [{role:'user', content: prompt}],
    max_tokens: 800
  });
  // Best-effort parse
  try{
    const text = res.choices[0].message.content;
    return JSON.parse(text);
  }catch(e){
    return { summary: 'Could not parse AI response', raw: res };
  }
}

export async function generateWorkoutPlan(profile){
  const prompt = `Create a 4-week strength training plan for weight gain, 4 days/week, progressive overload.
Profile: Age ${profile.age}, Height ${profile.height_cm}, Weight ${profile.weight_kg}, Target ${profile.target_kg}.
Return JSON with keys: summary, weeks (array)`;
  const res = await client.chat.completions.create({
    model: "gpt-4o-mini",
    messages: [{role:'user', content: prompt}],
    max_tokens: 800
  });
  try{
    const text = res.choices[0].message.content;
    return JSON.parse(text);
  }catch(e){
    return { summary: 'Could not parse AI response', raw: res };
  }
}
