import express from 'express';
import { generateMealPlan, generateWorkoutPlan } from '../services/aiService.js';
const router = express.Router();

router.post('/mealplan', async (req,res)=>{
  try{
    const { profile, targets } = req.body;
    const plan = await generateMealPlan(profile, targets);
    res.json(plan);
  }catch(e){ res.status(500).json({error: e.message}); }
});

router.post('/workoutplan', async (req,res)=>{
  try{
    const { profile } = req.body;
    const plan = await generateWorkoutPlan(profile);
    res.json(plan);
  }catch(e){ res.status(500).json({error: e.message}); }
});

export default router;
