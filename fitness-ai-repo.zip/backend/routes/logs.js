import express from 'express';
import { supabase } from '../services/supabaseClient.js';
const router = express.Router();

router.post('/meal', async (req,res)=>{
  const log = req.body;
  const { data, error } = await supabase.from('meal_logs').insert([log]).select().single();
  if(error) return res.status(500).json({error: error.message});
  res.json(data);
});

router.post('/progress', async (req,res)=>{
  const log = req.body;
  const { data, error } = await supabase.from('progress').insert([log]).select().single();
  if(error) return res.status(500).json({error: error.message});
  res.json(data);
});

export default router;
