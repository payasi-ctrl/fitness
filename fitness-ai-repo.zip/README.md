# Fitness AI App (Ready-to-upload)

This repository contains a ready-to-upload code package (frontend + backend + GitHub Actions) that builds an Android APK via GitHub Actions.

**What I provide:**
- Frontend React app (Tailwind-ready) in `/frontend`
- Backend Node/Express server in `/backend`
- GitHub Actions workflow to build an Android APK using Capacitor in `.github/workflows/android-build.yml`
- `supabase.sql` with table definitions
- `.env.example` showing required secrets
- Simple instructions below.

**Important:** You must add secrets to the GitHub repository before the workflow can successfully build:
- `OPENAI_API_KEY`
- `SUPABASE_URL`
- `SUPABASE_KEY` (service_role key)
- `JWT_SECRET`

## Quick steps (very short)
1. Create a GitHub repository.
2. Upload the files from this ZIP (or push via git).
3. In GitHub repo settings → Secrets → Add the four secrets above.
4. Open **Actions** and allow the Android workflow to run (it should auto-run on push).
5. After success, download the APK from Actions → latest run → Artifacts.

See more detailed instructions in `GUIDE.txt`.
