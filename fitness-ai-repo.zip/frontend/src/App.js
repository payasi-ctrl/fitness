import React, {useState, useEffect} from 'react';

export default function App(){
  const [profile, setProfile] = useState({age:20, height_cm:183, weight_kg:50, target_kg:70, vegetarian:true});
  const [targets, setTargets] = useState({calories:2800, protein:120});
  useEffect(()=> {
    const weight = profile.weight_kg;
    const height = profile.height_cm;
    const age = profile.age;
    const bmr = Math.round(10*weight + 6.25*height - 5*age + 5);
    const maintenance = Math.round(bmr * 1.4);
    const calories = maintenance + 850;
    const protein = Math.round(1.8 * profile.target_kg);
    setTargets({calories, protein});
  }, [profile]);
  return (
    <div style={{fontFamily:'sans-serif', padding:20}}>
      <h1>Fitness AI (Demo)</h1>
      <div>
        <h3>Profile</h3>
        <div>Age: <input value={profile.age} onChange={e=>setProfile({...profile, age:+e.target.value})} /></div>
        <div>Height cm: <input value={profile.height_cm} onChange={e=>setProfile({...profile, height_cm:+e.target.value})} /></div>
        <div>Weight kg: <input value={profile.weight_kg} onChange={e=>setProfile({...profile, weight_kg:+e.target.value})} /></div>
        <div>Target kg: <input value={profile.target_kg} onChange={e=>setProfile({...profile, target_kg:+e.target.value})} /></div>
      </div>
      <div style={{marginTop:20}}>
        <h3>Targets</h3>
        <div>Calories/day: <strong>{targets.calories} kcal</strong></div>
        <div>Protein/day: <strong>{targets.protein} g</strong></div>
      </div>
      <div style={{marginTop:20}}>
        <p>This is a starter app. Follow the GUIDE.txt to build an APK via GitHub Actions.</p>
      </div>
    </div>
  );
}
