-- Supabase table setup
create table users (
  id uuid default gen_random_uuid() primary key,
  name text,
  age int,
  height_cm int,
  weight_kg numeric,
  target_kg numeric,
  vegetarian boolean default true,
  created_at timestamptz default now()
);

create table meal_logs (
  id uuid default gen_random_uuid() primary key,
  user_id uuid references users(id),
  date date,
  meal_name text,
  calories int,
  protein int,
  created_at timestamptz default now()
);

create table progress (
  id uuid default gen_random_uuid() primary key,
  user_id uuid references users(id),
  date date,
  weight numeric,
  created_at timestamptz default now()
);
